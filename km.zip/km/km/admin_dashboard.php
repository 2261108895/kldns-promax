<?php
session_start();
require 'db_config.php';

// 1. 先处理表单提交（核心：用PRG模式，提交后重定向，避免重复提交）
$success = '';
$error = '';
// 从会话中获取提示信息（重定向后显示）
if (isset($_SESSION['success_msg'])) {
    $success = $_SESSION['success_msg'];
    unset($_SESSION['success_msg']); // 显示后立即销毁，避免刷新重复显示
}
if (isset($_SESSION['error_msg'])) {
    $error = $_SESSION['error_msg'];
    unset($_SESSION['error_msg']);
}

// 验证登录状态
if (!isset($_SESSION['admin_login']) || !$_SESSION['admin_login']) {
    header("Location: admin_login.php");
    exit;
}

// 2. 卡密生成逻辑（提交后重定向）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_card'])) {
    $point = (int)$_POST['point'];
    $expire_time = $_POST['expire_time'];
    $use_count = (int)$_POST['use_count'];
    $batch_num = (int)$_POST['batch_num'] ?: 1;
    $custom_code = trim($_POST['custom_code']);

    // 校验：批量生成时不可用自定义卡密
    if ($batch_num > 1 && !empty($custom_code)) {
        $_SESSION['error_msg'] = '批量生成时不可使用自定义卡密，请清空自定义卡密或设置批量数量为1！';
        header("Location: admin_dashboard.php"); // 重定向到当前页
        exit;
    }

    try {
        $is_success = true;
        for ($i = 0; $i < $batch_num; $i++) {
            $card_code = !empty($custom_code) ? strtoupper($custom_code) : strtoupper(uniqid() . substr(md5(rand()), 0, 6));
            
            // 校验自定义卡密是否已存在
            $check_stmt = $pdo->prepare("SELECT id FROM kldns_cards WHERE card_code = :code");
            $check_stmt->execute([':code' => $card_code]);
            if ($check_stmt->fetch()) {
                $_SESSION['error_msg'] = '自定义卡密已存在，请更换！';
                $is_success = false;
                break;
            }

            $stmt = $pdo->prepare("INSERT INTO kldns_cards (card_code, point, expire_time, use_count) 
                                  VALUES (:code, :point, :expire, :use_count)");
            $stmt->execute([
                ':code' => $card_code,
                ':point' => $point,
                ':expire' => $expire_time,
                ':use_count' => $use_count
            ]);
        }

        if ($is_success) {
            $_SESSION['success_msg'] = "成功生成 " . $batch_num . " 个卡密！";
        }
    } catch (PDOException $e) {
        $_SESSION['error_msg'] = '卡密生成失败：' . $e->getMessage();
    }

    // 关键：无论成功/失败，都重定向到当前页，避免POST重复提交
    header("Location: admin_dashboard.php");
    exit;
}

// 3. 单个卡密删除（保持PRG模式）
if (isset($_GET['delete_id'])) {
    $id = (int)$_GET['delete_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM kldns_cards WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $_SESSION['success_msg'] = "卡密删除成功！";
    } catch (PDOException $e) {
        $_SESSION['error_msg'] = '卡密删除失败：' . $e->getMessage();
    }
    header("Location: admin_dashboard.php");
    exit;
}

// 4. 批量删除（保持PRG模式）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['batch_delete'])) {
    $ids = $_POST['card_ids'] ?? [];
    if (!empty($ids)) {
        try {
            $id_str = implode(',', array_map('intval', $ids));
            $stmt = $pdo->prepare("DELETE FROM kldns_cards WHERE id IN ($id_str)");
            $stmt->execute();
            $_SESSION['success_msg'] = "成功删除 " . count($ids) . " 个卡密！";
        } catch (PDOException $e) {
            $_SESSION['error_msg'] = '批量删除失败：' . $e->getMessage();
        }
    } else {
        $_SESSION['error_msg'] = "请选择要删除的卡密！";
    }
    header("Location: admin_dashboard.php");
    exit;
}

// 5. 批量导出（无需重定向，因是下载操作）
if (isset($_POST['batch_export'])) {
    $stmt = $pdo->query("SELECT card_code, point, expire_time, use_count, used_count, status 
                        FROM kldns_cards ORDER BY created_at DESC");
    $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="卡密列表_' . date('YmdHis') . '.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['卡密', '积分', '过期时间', '总可使用次数', '已使用次数', '状态（1=有效，0=无效）']);
    foreach ($cards as $card) {
        fputcsv($output, $card);
    }
    fclose($output);
    exit;
}

// 6. 获取所有卡密（显示用）
$stmt = $pdo->query("SELECT * FROM kldns_cards ORDER BY created_at DESC");
$cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>管理员控制台 - 卡密管理</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: '微软雅黑', sans-serif; }
        body {
            background: url(https://t.alcy.cc/ycy) no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            padding: 2rem;
            color: #fff;
        }
        .glass-box {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
        h1, h2 { margin-bottom: 1.5rem; text-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .form-group { margin-bottom: 1rem; display: inline-block; margin-right: 1rem; width: calc(25% - 1rem); vertical-align: top; }
        @media (max-width: 1200px) { .form-group { width: calc(33% - 1rem); } }
        @media (max-width: 768px) { .form-group { width: 100%; margin-right: 0; } }
        label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        input, select {
            width: 100%;
            padding: 0.6rem;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px;
            background: rgba(255,255,255,0.1);
            color: #fff;
            outline: none;
        }
        input::placeholder { color: rgba(255,255,255,0.6); }
        button {
            padding: 0.6rem 1.2rem;
            background: #2196F3;
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-right: 0.5rem;
            transition: background 0.3s;
        }
        button:hover { background: #1976D2; }
        button.danger { background: #f44336; }
        button.danger:hover { background: #d32f2f; }
        .table-container { overflow-x: auto; margin-top: 1rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td {
            padding: 0.8rem;
            text-align: left;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        th { background: rgba(255,255,255,0.15); font-weight: 600; }
        tr:hover { background: rgba(255,255,255,0.1); }
        .status-active { color: #4CAF50; }
        .status-inactive { color: #ff9800; }
        .msg { padding: 1rem; border-radius: 6px; margin-bottom: 1rem; text-align: center; }
        .success { background: rgba(76, 175, 80, 0.2); color: #c8e6c9; }
        .error { background: rgba(244, 67, 54, 0.2); color: #ffcdd2; }
        .logout { text-align: right; margin-bottom: 1rem; }
        .logout a { color: #fff; text-decoration: none; background: rgba(255,255,255,0.1); padding: 0.5rem 1rem; border-radius: 6px; }
        .edit-btn {
            color: #fff;
            background: #ff9800;
            padding: 0.4rem 0.8rem;
            border-radius: 4px;
            text-decoration: none;
            margin-right: 0.5rem;
            transition: background 0.3s;
        }
        .edit-btn:hover { background: #e68900; }
        .delete-btn {
            color: #fff;
            background: #f44336;
            padding: 0.4rem 0.8rem;
            border-radius: 4px;
            text-decoration: none;
            transition: background 0.3s;
        }
        .delete-btn:hover { background: #d32f2f; }
    </style>
</head>
<body>
    <div class="logout">
        <a href="admin_login.php?logout=1">退出登录</a>
    </div>

    <!-- 卡密生成区域 -->
    <div class="glass-box">
        <h2>卡密生成</h2>
        <?php if ($success) echo "<div class='msg success'>$success</div>"; ?>
        <?php if ($error) echo "<div class='msg error'>$error</div>"; ?>
        <form method="POST">
            <div class="form-group">
                <label>兑换积分</label>
                <input type="number" name="point" min="1" value="100" required>
            </div>
            <div class="form-group">
                <label>过期时间</label>
                <input type="datetime-local" name="expire_time" required>
            </div>
            <div class="form-group">
                <label>总可使用次数</label>
                <input type="number" name="use_count" min="1" value="1" required>
            </div>
            <div class="form-group">
                <label>自定义卡密（选填，为空则自动生成）</label>
                <input type="text" name="custom_code" placeholder="例如：VIP20240601" maxlength="50">
            </div>
            <div class="form-group">
                <label>批量生成数量（默认1）</label>
                <input type="number" name="batch_num" min="1" value="1">
            </div>
            <div style="clear: both; margin-top: 1rem;">
                <button type="submit" name="generate_card">生成卡密</button>
            </div>
        </form>
    </div>

    <!-- 卡密管理区域 -->
    <div class="glass-box">
        <h2>卡密管理</h2>
        <form method="POST" id="cardForm">
            <div style="margin-bottom: 1rem;">
                <button type="submit" name="batch_delete" class="danger" onclick="return confirm('确定删除选中卡密？')">批量删除</button>
                <button type="submit" name="batch_export">批量导出（CSV）</button>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <<th><input type="checkbox" id="checkAll"></</th>
                            <<th>ID</</th>
                            <<th>卡密</</th>
                            <<th>积分</</th>
                            <<th>过期时间</</th>
                            <<th>总使用次数</</th>
                            <<th>已使用次数</</th>
                            <<th>状态</</th>
                            <<th>操作</</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($cards)): ?>
                            <tr><td colspan="9" style="text-align: center; padding: 2rem;">暂无卡密数据</td></tr>
                        <?php else: ?>
                            <?php foreach ($cards as $card): ?>
                                <tr>
                                    <td><input type="checkbox" name="card_ids[]" value="<?php echo $card['id']; ?>"></td>
                                    <td><?php echo $card['id']; ?></td>
                                    <td><?php echo $card['card_code']; ?></td>
                                    <td><?php echo $card['point']; ?></td>
                                    <td><?php echo $card['expire_time']; ?></td>
                                    <td><?php echo $card['use_count']; ?></td>
                                    <td><?php echo $card['used_count']; ?></td>
                                    <td>
                                        <?php 
                                        $now = date('Y-m-d H:i:s');
                                        if ($card['status'] == 0) {
                                            echo '<span class="status-inactive">已用完</span>';
                                        } elseif ($card['expire_time'] < $now) {
                                            echo '<span class="status-inactive">已过期</span>';
                                        } else {
                                            echo '<span class="status-active">有效</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <a href="admin_edit_card.php?edit_id=<?php echo $card['id']; ?>" class="edit-btn">编辑</a>
                                        <a href="?delete_id=<?php echo $card['id']; ?>" onclick="return confirm('确定删除此卡密？')" class="delete-btn">删除</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </form>
    </div>

    <script>
        document.getElementById('checkAll').onchange = function() {
            const checkboxes = document.getElementsByName('card_ids[]');
            checkboxes.forEach(checkbox => checkbox.checked = this.checked);
        };
    </script>
</body>
</html>