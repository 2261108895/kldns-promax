<?php
session_start();
// 新增：退出登录逻辑（若从其他页面跳转退出，直接销毁会话）
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin_login.php");
    exit;
}

require 'db_config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admin_name = trim($_POST['admin_name']);
    $admin_pwd = trim($_POST['admin_pwd']);

    $stmt = $pdo->prepare("SELECT * FROM kldns_admin WHERE admin_name = :name");
    $stmt->bindParam(':name', $admin_name);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin && password_verify($admin_pwd, $admin['admin_pwd'])) {
        $_SESSION['admin_login'] = true;
        header("Location: admin_dashboard.php");
        exit;
    } else {
        $error = '账号或密码错误！';
    }
}
?>
<!-- 原有HTML样式保持不变，无需修改 -->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>管理员登录</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: '微软雅黑', sans-serif; }
        body {
            background: url(https://t.alcy.cc/ycy) no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .glass-box {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 3rem;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
        h1 { text-align: center; color: #fff; margin-bottom: 2rem; text-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; color: #fff; margin-bottom: 0.5rem; font-weight: 500; }
        input {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px;
            background: rgba(255,255,255,0.1);
            color: #fff;
            font-size: 1rem;
            outline: none;
        }
        input::placeholder { color: rgba(255,255,255,0.6); }
        button {
            width: 100%;
            padding: 0.8rem;
            background: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover { background: #45a049; }
        .error { color: #ff4444; text-align: center; margin-top: 1rem; }
    </style>
</head>
<body>
    <div class="glass-box">
        <h1>管理员登录</h1>
        <form method="POST">
            <div class="form-group">
                <label>账号</label>
                <input type="text" name="admin_name" placeholder="输入管理员账号" required>
            </div>
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="admin_pwd" placeholder="输入管理员密码" required>
            </div>
            <button type="submit">登录</button>
            <?php if ($error) echo "<div class='error'>$error</div>"; ?>
        </form>
    </div>
</body>
</html>