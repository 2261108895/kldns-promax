<?php
session_start();
// 1. 开启PHP错误显示（关键：解决空白页，方便定位问题）
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'db_config.php';

// 验证登录 + 退出登录逻辑
if (!isset($_SESSION['admin_login']) || !$_SESSION['admin_login']) {
    header("Location: admin_login.php");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin_login.php");
    exit;
}

// 2. 获取待编辑卡密ID（增加合法性校验）
$edit_id = 0;
if (isset($_GET['edit_id']) && is_numeric($_GET['edit_id'])) {
    $edit_id = (int)$_GET['edit_id'];
}
if ($edit_id === 0) {
    echo "<script>alert('无效的卡密ID');window.location.href='admin_dashboard.php';</script>";
    exit;
}

// 3. 获取卡密数据（增加异常捕获）
$card = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM kldns_cards WHERE id = :id");
    $stmt->bindParam(':id', $edit_id, PDO::PARAM_INT); // 明确参数类型，避免SQL注入
    $stmt->execute();
    $card = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<script>alert('获取卡密数据失败：" . $e->getMessage() . "');window.location.href='admin_dashboard.php';</script>";
    exit;
}
if (!$card) {
    echo "<script>alert('卡密不存在或已被删除');window.location.href='admin_dashboard.php';</script>";
    exit;
}

// 4. 处理编辑提交（核心修复：增加异常捕获 + 明确跳转）
$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 表单参数验证（避免空值/非法值）
    $point = isset($_POST['point']) && is_numeric($_POST['point']) ? (int)$_POST['point'] : 0;
    $expire_time = isset($_POST['expire_time']) ? trim($_POST['expire_time']) : '';
    $use_count = isset($_POST['use_count']) && is_numeric($_POST['use_count']) ? (int)$_POST['use_count'] : 0;

    // 基础校验
    if ($point < 1) {
        $error = '积分必须大于0！';
    } elseif (empty($expire_time)) {
        $error = '请选择过期时间！';
    } elseif ($use_count < $card['used_count']) {
        $error = '总使用次数不能小于已使用次数（当前已使用：' . $card['used_count'] . '）！';
    } else {
        // 数据库更新（增加try-catch捕获错误）
        try {
            $now = date('Y-m-d H:i:s');
            $status = ($use_count >= $card['used_count'] && $expire_time > $now) ? 1 : 0;

            $stmt = $pdo->prepare("UPDATE kldns_cards SET 
                                  point = :point, 
                                  expire_time = :expire, 
                                  use_count = :use_count,
                                  status = :status 
                                  WHERE id = :id");
            
            // 明确参数绑定（避免遗漏）
            $stmt->execute([
                ':point' => $point,
                ':expire' => $expire_time,
                ':use_count' => $use_count,
                ':status' => $status,
                ':id' => $edit_id
            ]);

            // 修复：保存成功后跳转（避免页面停滞）
            $success = "卡密编辑成功！";
            // 刷新当前页，显示最新数据
            echo "<script>setTimeout(function(){window.location.href='admin_edit_card.php?edit_id=" . $edit_id . "';},1500);</script>";
        } catch (PDOException $e) {
            $error = '修改失败：' . $e->getMessage(); // 显示具体错误，方便排查
        }
    }
}

// 格式化过期时间（适配datetime-local输入框）
$expire_time_formatted = date('Y-m-d\TH:i', strtotime($card['expire_time']));
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>编辑卡密 - 管理员控制台</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: '微软雅黑', sans-serif; }
        body {
            background: url(https://t.alcy.cc/ycy) no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            padding: 2rem;
            color: #fff;
        }
        .glass-box {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 2rem;
            max-width: 800px;
            margin: 0 auto;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
        .logout { text-align: right; margin-bottom: 1rem; }
        .logout a { color: #fff; text-decoration: none; background: rgba(255,255,255,0.1); padding: 0.5rem 1rem; border-radius: 6px; }
        h1 { margin-bottom: 2rem; text-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px;
            background: rgba(255,255,255,0.1);
            color: #fff;
            outline: none;
            font-size: 1rem;
        }
        input[readonly] { background: rgba(255,255,255,0.05); cursor: not-allowed; }
        .btn-group { margin-top: 2rem; }
        button {
            padding: 0.8rem 1.5rem;
            background: #2196F3;
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s;
            margin-right: 1rem;
        }
        button:hover { background: #1976D2; }
        button.cancel { background: #f44336; }
        button.cancel:hover { background: #d32f2f; }
        .msg {
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1.5rem;
            text-align: center;
            font-size: 1.1rem;
        }
        .success { background: rgba(76, 175, 80, 0.2); color: #c8e6c9; }
        .error { background: rgba(244, 67, 54, 0.2); color: #ffcdd2; }
        small { color: rgba(255,255,255,0.7); display: block; margin-top: 0.3rem; }
    </style>
</head>
<body>
    <div class="logout">
        <a href="?logout=1">退出登录</a>
    </div>

    <div class="glass-box">
        <h1>编辑卡密（ID：<?php echo $card['id']; ?>）</h1>
        <!-- 显示成功/错误信息（不再空白） -->
        <?php if ($success) echo "<div class='msg success'>$success</div>"; ?>
        <?php if ($error) echo "<div class='msg error'>$error</div>"; ?>

        <form method="POST">
            <div class="form-group">
                <label>卡密（不可修改）</label>
                <input type="text" value="<?php echo htmlspecialchars($card['card_code']); ?>" readonly>
            </div>
            <div class="form-group">
                <label>兑换积分</label>
                <input type="number" name="point" min="1" value="<?php echo $card['point']; ?>" required>
            </div>
            <div class="form-group">
                <label>过期时间</label>
                <input type="datetime-local" name="expire_time" value="<?php echo $expire_time_formatted; ?>" required>
                <small>格式：年-月-日 时:分（需晚于当前时间，否则卡密会变为“已过期”）</small>
            </div>
            <div class="form-group">
                <label>总可使用次数</label>
                <input type="number" name="use_count" min="<?php echo $card['used_count']; ?>" value="<?php echo $card['use_count']; ?>" required>
                <small>当前已使用：<?php echo $card['used_count']; ?> 次，不可小于已使用次数</small>
            </div>
            <div class="btn-group">
                <button type="submit">保存修改</button>
                <button type="button" class="cancel" onclick="window.location.href='admin_dashboard.php'">取消返回</button>
            </div>
        </form>
    </div>
</body>
</html>