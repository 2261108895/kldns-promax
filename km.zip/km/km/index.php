<?php
require 'db_config.php';

$msg = '';
$msg_type = '';

// 兑换逻辑（保持不变）
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $card_code = strtoupper(trim($_POST['card_code'])); 

    $stmt = $pdo->prepare("SELECT * FROM kldns_users WHERE username = :name");
    $stmt->bindParam(':name', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) {
        $msg = '用户名不存在！';
        $msg_type = 'error';
        goto end;
    }

    $now = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("SELECT * FROM kldns_cards WHERE card_code = :code AND status = 1 AND expire_time > :now");
    $stmt->execute([':code' => $card_code, ':now' => $now]);
    $card = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$card) {
        $msg = '卡密无效或已过期！';
        $msg_type = 'error';
        goto end;
    }

    if ($card['used_count'] >= $card['use_count']) {
        $msg = '此卡密已达最大使用次数！';
        $msg_type = 'error';
        $stmt = $pdo->prepare("UPDATE kldns_cards SET status = 0 WHERE id = :id");
        $stmt->execute([':id' => $card['id']]);
        goto end;
    }

    try {
        $pdo->beginTransaction();

        $new_point = $user['point'] + $card['point'];
        $stmt = $pdo->prepare("UPDATE kldns_users SET point = :point WHERE username = :name");
        $stmt->execute([':point' => $new_point, ':name' => $username]);

        $new_used_count = $card['used_count'] + 1;
        $status = ($new_used_count >= $card['use_count']) ? 0 : 1;
        $stmt = $pdo->prepare("UPDATE kldns_cards SET used_count = :used, status = :status WHERE id = :id");
        $stmt->execute([':used' => $new_used_count, ':status' => $status, ':id' => $card['id']]);

        $pdo->commit();
        $msg = '兑换成功！您已获得 ' . $card['point'] . ' 积分，当前总积分：' . $new_point;
        $msg_type = 'success';
    } catch (Exception $e) {
        $pdo->rollBack();
        $msg = '兑换失败：' . $e->getMessage();
        $msg_type = 'error';
    }

    end:;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>积分卡密兑换</title>
    <style>
        /* 原有样式保持不变，新增返回按钮样式（与兑换按钮协调） */
        .btn-group {
            display: flex;
            gap: 1rem; /* 按钮间距 */
            margin-top: 1rem;
        }
        .btn-group button {
            flex: 1; /* 按钮平分宽度 */
        }
        /* 其他原有样式... */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: '微软雅黑', sans-serif; }
        body {
            background: url(https://t.alcy.cc/ycy) no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 1rem;
        }
        .glass-box {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 3rem;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.18);
            width: 100%;
            max-width: 500px;
        }
        h1 { text-align: center; color: #fff; margin-bottom: 2rem; text-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; color: #fff; margin-bottom: 0.5rem; font-weight: 500; }
        input {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px;
            background: rgba(255,255,255,0.1);
            color: #fff;
            font-size: 1rem;
            outline: none;
        }
        input::placeholder { color: rgba(255,255,255,0.6); }
        button {
            padding: 0.8rem;
            background: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover { background: #45a049; }
        button.return-btn { background: #2196F3; } /* 返回按钮蓝色区分 */
        button.return-btn:hover { background: #1976D2; }
        .msg {
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .success { background: rgba(76, 175, 80, 0.2); color: #c8e6c9; }
        .error { background: rgba(244, 67, 54, 0.2); color: #ffcdd2; }
    </style>
</head>
<body>
    <div class="glass-box">
        <h1>积分卡密兑换</h1>
        <?php if ($msg): ?>
            <div class="msg <?php echo $msg_type; ?>"><?php echo $msg; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" placeholder="输入您的用户名" required>
            </div>
            <div class="form-group">
                <label>卡密</label>
                <input type="text" name="card_code" placeholder="输入卡密（不分大小写）" required>
            </div>
            <!-- 新增：返回按钮 + 兑换按钮组 -->
            <div class="btn-group">
                <button type="button" class="return-btn" onclick="window.location.href='/home'">返回</button>
                <button type="submit">立即兑换</button>
            </div>
        </form>
    </div>
</body>
</html>