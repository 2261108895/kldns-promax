﻿<?php
// 数据库配置
$db_host = '127.0.0.1';
$db_name = '数据库名';
$db_user = '数据库用户名';
$db_pwd = '数据库密码';

// PDO连接数据库
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pwd);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败：" . $e->getMessage());
}