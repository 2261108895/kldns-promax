<?php
/**
 * Created by PhpStorm.
 * User: me
 * Date: 2019/4/14
 * Time: 16:41
 */

namespace App\Http\Controllers\Home;


use App\Helper;
use App\Http\Controllers\Controller;
use App\Models\Domain;
use App\Models\DomainRecord;
use App\Models\User;
use App\Models\UserPointRecord;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    public function post(Request $request)
    {
        $action = $request->post('action');
        switch ($action) {
            case 'verify':
                return $this->verify($request);
            case 'profile':
                return $this->profile($request);
            case 'recordList':
                return $this->recordList($request);
            case 'domainList':
                return $this->domainList($request);
            case 'pointRecord':
                return $this->pointRecord($request);
        }
        if (Auth::user()->status != 2) {
            return ['status' => -1, 'message' => "对不起，请先完成认证！<a href='/home/profile'>点击认证</a>"];
        }

        switch ($action) {
            case 'recordStore':
                return $this->recordStore($request);
            case 'recordDelete':
                return $this->recordDelete($request);
            default:
                return ['status' => -1, 'message' => '对不起，此操作不存在！'];
        }
    }

    private function verify(Request $request)
    {
        $result = ['status' => -1];
        $user = Auth::user();
        if ($user->status != 1) {
            $result['message'] = '当前状态不需要认证';
        } else {
            list($ret, $error) = Helper::sendVerifyEmail($user);
            if ($ret) {
                $result = ['status' => 0, 'message' => "已将认证邮件发送到{$user->email}，请注意查收！"];
            } else {
                $result['message'] = "发送邮件失败:" . $error;
            }
        }
        return $result;
    }

    private function profile(Request $request)
    {
        $result = ['status' => -1];
        $old_password = $request->post('old_password');
        $new_password = $request->post('new_password');
        if (strlen($old_password) < 5) {
            $result['message'] = '旧密码验证失败';
        } elseif (!Hash::check($old_password, Auth::user()->password)) {
            $result['message'] = '旧密码验证失败';
        } elseif (strlen($new_password) < 5) {
            $result['message'] = '新密码太简单';
        } else {
            if (User::where('uid', Auth::id())->update([
                'password' => Hash::make($new_password),
                'sid' => md5(uniqid() . Str::random())
            ])) {
                $result = ['status' => 0, 'message' => '修改成功'];
            } else {
                $result['message'] = '修改失败，请稍后再试！';
            }
        }
        return $result;
    }

    private function pointRecord(Request $request)
    {
        $data = UserPointRecord::search()->where('uid', Auth::id())->orderBy('id', 'desc')->pageSelect();
        return ['status' => 0, 'message' => '', 'data' => $data];
    }

    private function recordStore(Request $request)
    {
        $result = ['status' => -1];
        $id = intval($request->post('id'));
        $data = [
            'uid' => Auth::id(),
            'did' => intval($request->post('did')),
            'name' => $request->post('name'),
            'type' => $request->post('type'),
            'line_id' => $request->post('line_id'),
            'value' => $request->post('value'),
            'line' => '默认'
        ];
        $cfg = [
            'name_max_len' => intval(config('sys.record.name_max_len', 63)),
            'forbid_cname_root' => intval(config('sys.record.forbid_cname_root', 1)) == 1,
            'forbid_private_ip' => intval(config('sys.record.forbid_private_ip', 1)) == 1,
            'forbid_invalid_ipv4' => intval(config('sys.record.forbid_invalid_ipv4', 1)) == 1,
            'forbid_invalid_ipv6' => intval(config('sys.record.forbid_invalid_ipv6', 1)) == 1,
            'forbid_cname_self' => intval(config('sys.record.forbid_cname_self', 1)) == 1,
            'txt_max_len' => intval(config('sys.record.txt_max_len', 255)),
            'txt_ascii_only' => intval(config('sys.record.txt_ascii_only', 1)) == 1,
        ];
        $data['name'] = is_string($data['name']) ? trim($data['name']) : '';
        $data['type'] = is_string($data['type']) ? strtoupper(trim($data['type'])) : '';
        $data['value'] = is_string($data['value']) ? trim($data['value']) : '';
        if (strpos($data['name'], '*') !== false) {
            return ['status' => -1, 'message' => '不支持泛解析，请填写具体主机记录'];
        }
        if ($data['name'] !== '' && $data['name'] !== '@') {
            list($check, $error) = Helper::checkDomainName($data['name']);
            if (!$check) {
                $result['message'] = $error;
                return $result;
            }
        }
        if ($id && !$record = DomainRecord::where('uid', Auth::id())->where('id', $id)->first()) {
            $result['message'] = '记录不存在';
        } elseif (!$data['value']) {
            $result['message'] = '请输入记录值';
        } elseif (!in_array($data['type'], ['A', 'AAAA', 'CNAME', 'MX', 'TXT'])) {
            $result['message'] = '不支持的记录类型';
        } elseif ($data['name'] !== '' && $data['name'] !== '@' && strlen($data['name']) > $cfg['name_max_len']) {
            $result['message'] = '主机记录长度不能超过' . $cfg['name_max_len'] . '字符';
        } elseif (!$id && DomainRecord::where('did', $data['did'])->where('name', $data['name'])->where('uid', '!=', Auth::id())->where('line_id', $data['line_id'])->first()) {
            $result['message'] = '此主机记录已被使用';
        } elseif (!$domain = Domain::available()->where('did', $data['did'])->first()) {
            $result['message'] = '域名不存在，或无此权限';
        } elseif (!$dns = $domain->dnsConfig) {
            $result['message'] = '域名配置错误[No Config]';
        } elseif (!$_dns = \App\Klsf\Dns\Helper::getModel($dns->dns)) {
            $result['message'] = '域名配置错误[Unsupporte]';
        } else {
            $_dns->config($dns->config);
            $lines = $_dns->getRecordLine($domain->domain_id, $domain->domain);
            $lineFound = false;
            foreach ($lines as $line) {
                if ($line['Id'] == $data['line_id']) {
                    $data['line'] = $line['Name'];
                    $lineFound = true;
                }
            }
            if (!$lineFound) {
                return ['status' => -1, 'message' => '请选择正确的线路'];
            }
            $label = ($data['name'] === '' || $data['name'] === '@') ? '@' : $data['name'];
            $fullName = ($label === '@') ? $domain->domain : ($label . '.' . $domain->domain);
            if ($cfg['forbid_cname_root'] && $data['type'] === 'CNAME' && $label === '@') {
                return ['status' => -1, 'message' => '根域不支持 CNAME，请使用 A/AAAA'];
            }
            if ($data['type'] === 'A') {
                if (!filter_var($data['value'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    return ['status' => -1, 'message' => 'A 记录值必须为合法 IPv4 地址'];
                }
                if ($cfg['forbid_private_ip']) {
                    if (!filter_var($data['value'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                        return ['status' => -1, 'message' => '不允许使用私有或保留地址'];
                    }
                }
                if ($cfg['forbid_invalid_ipv4']) {
                    if ($data['value'] === '0.0.0.0' || strpos($data['value'], '127.') === 0) {
                        return ['status' => -1, 'message' => '不允许使用无效或回环地址'];
                    }
                }
            } elseif ($data['type'] === 'AAAA') {
                if (!filter_var($data['value'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                    return ['status' => -1, 'message' => 'AAAA 记录值必须为合法 IPv6 地址'];
                }
                if ($cfg['forbid_private_ip']) {
                    if (!filter_var($data['value'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                        return ['status' => -1, 'message' => '不允许使用私有或保留地址'];
                    }
                }
                if ($cfg['forbid_invalid_ipv6']) {
                    $v = strtolower($data['value']);
                    if ($v === '::' || $v === '::1' || strpos($v, 'fe80:') === 0) {
                        return ['status' => -1, 'message' => '不允许使用无效或链路本地地址'];
                    }
                }
            } elseif ($data['type'] === 'CNAME' || $data['type'] === 'MX') {
                $host = rtrim($data['value'], '.');
                if (!preg_match('/^(?=.{1,253}$)(?!-)(?:[A-Za-z0-9-]{1,63}\.)+[A-Za-z]{2,}$/', $host)) {
                    return ['status' => -1, 'message' => ($data['type'] === 'CNAME' ? 'CNAME' : 'MX') . ' 记录值必须为合法域名'];
                }
                $data['value'] = $host;
                if ($cfg['forbid_cname_self'] && strtolower($host) === strtolower($fullName)) {
                    return ['status' => -1, 'message' => '记录值不能指向自身'];
                }
            } elseif ($data['type'] === 'TXT') {
                if (strlen($data['value']) > $cfg['txt_max_len']) {
                    return ['status' => -1, 'message' => 'TXT 记录长度不能超过' . $cfg['txt_max_len']];
                }
                if ($cfg['txt_ascii_only']) {
                    if (preg_match('/[\x00-\x1F]/', $data['value'])) {
                        return ['status' => -1, 'message' => 'TXT 记录不能包含控制字符'];
                    }
                    if (preg_match('/[^\x20-\x7E]/', $data['value'])) {
                        return ['status' => -1, 'message' => 'TXT 记录仅支持 ASCII 可见字符'];
                    }
                }
            }
            if ($id) {
                $conflictQuery = DomainRecord::where('did', $data['did'])->where('name', $data['name'])->where('id', '!=', $id);
                $existing = $conflictQuery->first();
                if ($existing) {
                    if ($data['type'] === 'CNAME' && $existing->type !== 'CNAME') {
                        return ['status' => -1, 'message' => '已存在其它类型记录，不能添加/修改为 CNAME'];
                    }
                    if ($data['type'] !== 'CNAME' && $existing->type === 'CNAME') {
                        return ['status' => -1, 'message' => '已存在 CNAME 记录，不能添加此类型'];
                    }
                }
                list($ret, $error) = $_dns->updateDomainRecord($record->record_id, $data['name'], $data['type'], $data['value'], $data['line_id'], $domain->domain_id, $domain->domain);
                if ($ret) {
                    if (DomainRecord::where('id', $id)->update($data)) {
                        $result = ['status' => 0, 'message' => '更新成功'];
                    } else {
                        $result['message'] = '更新失败，请稍后再试！';
                    }
                } else {
                    $result['message'] = '更新记录失败:' . $error;
                }
            } else {
                $conflictQuery = DomainRecord::where('did', $data['did'])->where('name', $data['name']);
                $existing = $conflictQuery->first();
                if ($existing) {
                    if ($data['type'] === 'CNAME' && $existing->type !== 'CNAME') {
                        return ['status' => -1, 'message' => '已存在其它类型记录，不能添加 CNAME'];
                    }
                    if ($data['type'] !== 'CNAME' && $existing->type === 'CNAME') {
                        return ['status' => -1, 'message' => '已存在 CNAME 记录，不能添加此类型'];
                    }
                }
                if ($domain->point > 0 && Auth::user()->point < $domain->point) {
                    $result['message'] = '账户剩余积分不足！';
                } else {
                    list($ret, $error) = $_dns->addDomainRecord($data['name'], $data['type'], $data['value'], $data['line_id'], $domain->domain_id, $domain->domain);
                    if ($ret) {
                        if ($domain->point > 0 && !User::point(Auth::id(), '消费', 0 - $domain->point, "添加记录[{$data['name']}.{$domain->domain}]({$data['line']})")) {
                            $result['message'] = '账户剩余积分不足！';
                            $_dns->deleteDomainRecord($ret['RecordId'], $domain->domain_id, $domain->domain);
                        } else {
                            $data['record_id'] = $ret['RecordId'];
                            if (DomainRecord::create($data)) {
                                $result = ['status' => 0, 'message' => '添加成功'];
                            } else {
                                list($ret, $error) = $_dns->deleteDomainRecord($ret['RecordId'], $domain->domain_id, $domain->domain);
                                $result['message'] = '添加失败，请稍后再试！';
                            }
                        }
                    } else {
                        $result['message'] = '添加记录失败:' . $error;
                    }
                }
            }
        }
        return $result;
    }

    private function recordList(Request $request)
    {
        $id = intval($request->post('id'));
        $data = DomainRecord::where('uid', Auth::id())->where('did', $id)->orderBy('id', 'desc')->pageSelect();
        return ['status' => 0, 'message' => '', 'data' => $data];
    }

    private function domainList(Request $request)
    {
        $data = Domain::available()->orderBy('did', 'desc')->pageSelect();
        return ['status' => 0, 'message' => '', 'data' => $data];
    }

    private function recordDelete(Request $request)
    {
        $result = ['status' => -1];
        $id = intval($request->post('id'));
        if (!$id || !$row = DomainRecord::where('uid', Auth::id())->where('id', $id)->first()) {
            $result['message'] = '记录不存在';
        } elseif (!$domain = Domain::available()->where('did', $row->did)->first()) {
            $result['message'] = '域名不存在，或无此权限';
        } elseif (!$dns = $domain->dnsConfig) {
            $result['message'] = '域名配置错误[No Config]';
        } elseif (!$_dns = \App\Klsf\Dns\Helper::getModel($dns->dns)) {
            $result['message'] = '域名配置错误[Unsupporte]';
        } else {
            $_dns->config($dns->config);
            list($ret, $error) = $_dns->deleteDomainRecord($row->record_id, $domain->domain_id, $domain->domain);
            if ($ret) {
                if ($row->delete()) {
                    $result = ['status' => 0, 'message' => '删除成功'];
                } else {
                    $result['message'] = '删除失败，请稍后再试！';
                }
            } else {
                $result['message'] = '删除记录失败:' . $error;
            }
        }
        return $result;
    }
}