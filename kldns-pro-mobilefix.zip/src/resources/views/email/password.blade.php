<center>
    <h1>用户密码重置</h1>
    <p style="font-size: 12px;color: grey">
        {{ $username }}，您好！您正在申请重置{{ $webName }}用户密码，请点击下面链接重新设置密码。<br>
        <a href="{{ $url }}">{{ $url }}</a>
    </p>
</center>