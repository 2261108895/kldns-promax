<?php
require_once 'config.php'; // 引入数据库配置文件

// 初始化页面状态（仅用于初始加载时判断该用户是否已签到，非登录态）
$hasSigned = false;
$totalPoint = 0;
$inputUsername = '';

// 如果是页面刷新且携带用户名（用于回显已输入的用户名和签到状态）
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['username'])) {
    $inputUsername = trim($_GET['username']);
    if (!empty($inputUsername)) {
        $today = date('Y-m-d');
        // 查该用户是否存在及今日签到状态
        $checkStmt = $pdo->prepare("SELECT point, sign_time FROM kldns_users WHERE username = :username");
        $checkStmt->bindParam(':username', $inputUsername);
        $checkStmt->execute();
        $user = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $totalPoint = $user['point'];
            // 判断今日是否已签到
            if (!empty($user['sign_time']) && date('Y-m-d', strtotime($user['sign_time'])) == $today) {
                $hasSigned = true;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>每日积分签到</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Microsoft YaHei", sans-serif;
        }

        /* 背景图样式 */
        .bg-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: -1;
            overflow: hidden;
        }

        .bg-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            filter: brightness(0.6);
        }

        /* 毛玻璃容器 */
        .sign-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 90%;
            max-width: 400px;
            padding: 2.5rem 1.5rem;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            text-align: center;
            color: #fff;
        }

        .sign-title {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        /* 用户名输入框 */
        .username-input {
            width: 100%;
            padding: 1rem;
            margin-bottom: 1rem;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-size: 1rem;
            outline: none;
            transition: border-color 0.3s ease;
        }

        .username-input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .username-input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
        }

        /* 按钮通用样式 */
        .btn {
            width: 100%;
            padding: 1rem;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* 签到按钮 */
        .sign-btn {
            background: linear-gradient(135deg, #f8d7da 0%, #764ba2 100%);
            color: #fff;
            margin-bottom: 1rem; /* 与返回按钮拉开间距 */
        }


        /* 返回按钮（差异化配色） */
        .back-btn {
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .btn:disabled {
            background: rgba(255, 255, 255, 0.3);
            box-shadow: none;
            cursor: not-allowed;
            opacity: 0.8;
        }

        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
        }

        /* 结果提示 & 状态提示 */
        .tip-box {
            margin: 1rem 0;
            padding: 1rem;
            border-radius: 8px;
            font-size: 1rem;
            opacity: 1;
        }

        .tip-success {
            background: rgba(72, 187, 120, 0.2);
            border: 1px solid rgba(72, 187, 120, 0.4);
            color: #d4edda;
        }

        .tip-error {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.4);
            color: #f8d7da;
        }

        .tip-info {
            background: rgba(23, 162, 184, 0.2);
            border: 1px solid rgba(23, 162, 184, 0.4);
            color: #d1ecf1;
        }
    </style>
</head>
<body>
    <!-- 背景图层 -->
    <div class="bg-container">
        <img src="https://t.alcy.cc/ycy" alt="背景图" class="bg-img" onError="this.src='https://picsum.photos/1080/1920';this.onerror=null;">
    </div>

    <!-- 毛玻璃签到容器 -->
    <div class="sign-container">
        <h2 class="sign-title">每日积分签到</h2>
        <h2 class="sign-title">随机100-500积分</h2>

        <!-- 用户名输入框 -->
        <input type="text" class="username-input" id="usernameInput" 
               placeholder="请输入你的用户名" value="<?php echo htmlspecialchars($inputUsername); ?>">
        
        <!-- 状态/结果提示框 -->
        <?php if (!empty($inputUsername)) : ?>
            <?php if (!$user) : ?>
                <div class="tip-box tip-error">用户名不存在，请核对后重试</div>
            <?php elseif ($hasSigned) : ?>
                <div class="tip-box tip-success">
                    用户名【<?php echo htmlspecialchars($inputUsername); ?>】今日已签到，当前总积分：<?php echo $totalPoint; ?>
                </div>
            <?php else : ?>
                <div class="tip-box tip-info">
                    用户名【<?php echo htmlspecialchars($inputUsername); ?>】今日未签到，点击按钮获取100-1500随机积分
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- 签到按钮 -->
        <button class="btn sign-btn" id="signBtn">确认签到</button>
        
        <!-- 新增：返回按钮 -->
        <a href="/home" target="_self">
            <button class="btn back-btn">返回</button>
        </a>
        
        <!-- 异步签到结果提示（初始隐藏） -->
        <div class="tip-box" id="asyncResultBox" style="display: none;"></div>
    </div>

    <!-- 签到逻辑JS -->
    <script>
        const usernameInput = document.getElementById('usernameInput');
        const signBtn = document.getElementById('signBtn');
        const asyncResultBox = document.getElementById('asyncResultBox');

        // 按钮点击事件
        signBtn.addEventListener('click', async () => {
            const username = usernameInput.value.trim();
            
            // 前端验证：用户名不能为空
            if (!username) {
                showAsyncResult('请先输入用户名', 'error');
                return;
            }

            // 防止重复点击
            signBtn.disabled = true;
            signBtn.textContent = '签到中...';
            showAsyncResult('', 'hide'); // 隐藏之前的结果

            try {
                // 异步提交用户名并执行签到
                const response = await fetch('do_checkin.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `username=${encodeURIComponent(username)}` // 传递用户名参数
                });

                const data = await response.json();
                if (data.success) {
                    // 签到成功：更新提示 + 禁用按钮
                    showAsyncResult(
                        `签到成功！用户名【${username}】获得${data.todayPoint}积分，当前总积分：${data.totalPoint}`, 
                        'success'
                    );
                    signBtn.textContent = '今日已签到';
                    signBtn.disabled = true;
                } else {
                    // 签到失败：显示错误 + 恢复按钮
                    showAsyncResult('签到失败：' + data.msg, 'error');
                    signBtn.disabled = false;
                    signBtn.textContent = '确认签到';
                }
            } catch (error) {
                showAsyncResult('网络错误，请稍后重试', 'error');
                signBtn.disabled = false;
                signBtn.textContent = '确认签到';
            }
        });

        // 显示异步结果的工具函数
        function showAsyncResult(text, type) {
            if (type === 'hide') {
                asyncResultBox.style.display = 'none';
                return;
            }
            asyncResultBox.style.display = 'block';
            asyncResultBox.textContent = text;
            asyncResultBox.className = `tip-box tip-${type}`;
        }
    </script>
</body>
</html>