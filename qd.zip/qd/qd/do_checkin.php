<?php
require_once 'config.php';

// 仅允许POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit(json_encode(['success' => false, 'msg' => '非法请求']));
}

// 接收前端传递的用户名
$username = isset($_POST['username']) ? trim($_POST['username']) : '';
if (empty($username)) {
    exit(json_encode(['success' => false, 'msg' => '用户名不能为空']));
}

$today = date('Y-m-d');
$randomPoint = rand(100, 500);

try {
    $pdo->beginTransaction();

    // 1. 先校验用户名是否存在
    $checkUserStmt = $pdo->prepare("SELECT point, sign_time FROM kldns_users WHERE username = :username");
    $checkUserStmt->bindParam(':username', $username);
    $checkUserStmt->execute();
    $user = $checkUserStmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception('用户名不存在，请核对后重试');
    }

    // 2. 检查今日是否已签到
    if (!empty($user['sign_time']) && date('Y-m-d', strtotime($user['sign_time'])) == $today) {
        throw new Exception('今日已签到，无需重复操作');
    }

    // 3. 更新积分和签到时间
    $updateStmt = $pdo->prepare("UPDATE kldns_users SET point = point + :point, sign_time = NOW() WHERE username = :username");
    $updateStmt->bindParam(':point', $randomPoint);
    $updateStmt->bindParam(':username', $username);
    $updateStmt->execute();

    // 4. 获取更新后的总积分
    $totalPoint = $user['point'] + $randomPoint; // 直接计算（避免二次查询，效率更高）

    $pdo->commit();
    exit(json_encode([
        'success' => true,
        'todayPoint' => $randomPoint,
        'totalPoint' => $totalPoint
    ]));

} catch (Exception $e) {
    $pdo->rollBack();
    exit(json_encode(['success' => false, 'msg' => $e->getMessage()]));
}