﻿<?php
// 数据库配置（请确保该文件不在网站根目录下，或设置严格权限）
$host = '127.0.0.1';     // 数据库地址
$dbname = '数据库名';        // 数据库名
$username = '数据库用户名';
$password = '数据库密码';    // 数据库密码

// 建立PDO连接（推荐PDO，比mysql扩展更安全）
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("数据库连接失败：" . $e->getMessage());
}
?>